Q-1: How can I fix missing resource string?

There is a ResourceString_EN.xml file attached at ResourceString folder in theme folder. You need to just import this resource strings from the admin area. For import resource string logged in to your store with Admin credentials then go to Admin > Configuration > Languages > Edit > and click on Import Resources button, select ResourceString_EN.xml  file and import it.


Q-2: How can I add static text content on homepage which is shown on demo site?
=>	For this you've to configure below html content in topic or in widget.
In demo site, we configured on HomePageText topic, so we recommended that.

For configure, go to Admin > Content Management > Topics > Click on Edit of HomePageText topic
and set below html (by click on richeditor Menu > Tools > Source Code)



<section class="bs_service_section">
	<div class="bs_service_main">
		<div class="bs_service_box">
			<div class="bs_service_sub_box">
				<div class="linearicons-plane l-icon"></div>
				<div class="bs_service_world_delivery">
					<h3>Worldwide Delivery</h3>
					<p>we ship to over 200 contries &amp; regions and time to time Delivery.</p>
				</div>
			</div>
		</div>
		<div class="bs_service_box">
			<div class="bs_service_sub_box">
				<div class="linearicons-bag-dollar l-icon"></div>
				<div class="bs_service_world_delivery">
					<h3>Safe Payement</h3>
					<p>Pay with the world's most popular and secure payment methods.</p>
				</div>
			</div>
		</div>
		<div class="bs_service_box">
			<div class="bs_service_sub_box">
				<div class="linearicons-license2 l-icon"></div>
				<div class="bs_service_world_delivery">
					<h3>Shop With Confidence</h3>
					<p>Our Buyer Protection covers your purchase from click to delivery.</p>
				</div>
			</div>
		</div>
		<div class="bs_service_box">
			<div class="bs_service_sub_box">
				<div class="linearicons-timer l-icon"></div>
				<div class="bs_service_world_delivery">
					<h3>24/7 Help center</h3>
					<p>Round-the-clock assistance for a smooth shopping experience.</p>
				</div>
			</div>
		</div>
	</div>
</section>