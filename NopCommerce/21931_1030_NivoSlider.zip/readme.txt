1. 'Nop.Plugin.Widgets.NivoSlider' directory contains source code.
2. 'Widgets.NivoSlider' contains binaries. Just drop it into \Plugins directory on your server.